var bankList = [];

var submitObjs = {
    methods:{
        testingabc:function(){
            console.log("test exist");
        }
    }
} 


